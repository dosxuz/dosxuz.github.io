# TryHackMe : Reversing ELF

## Crackme 2

Make the binary executable and run it :

```
kali@kali:~/reversing_elf/crackme2$ ./crackme2 
Usage: ./crackme2 password
```

Need password as the parameter.</br>

```
kali@kali:~/reversing_elf/crackme2$ file crackme2
crackme2: ELF 32-bit LSB executable, Intel 80386, version 1 (SYSV), dynamically linked, interpreter /lib/ld-linux.so.2, for GNU/Linux 2.6.32, BuildID[sha1]=b799eb348f3df15f6b08b3c37f8feb269a60aba7, not stripped
```

This says that the binary is not stripped.</br>

```
kali@kali:~/reversing_elf/crackme2$ ./crackme2 klaksjdlaksdjl
Access denied.
```

Running with random passwords gives access denied.
